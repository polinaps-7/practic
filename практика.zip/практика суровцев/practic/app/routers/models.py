from app.routers.database import Base
from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship


class User(Base):
  __tablename__ = "users"

  id = Column(Integer, primary_key=True, index=True)
  name = Column(String, index=True)
  email = Column(String, unique=True, index=True)
  hashed_password = Column(String)

class Group(Base):
  __tablename__ = "groups"

  id = Column(Integer, primary_key=True, index=True)
  name = Column(String, unique=True, index=True)


class Contact(Base):
  __tablename__ = "contacts"

  id = Column(Integer, primary_key=True, index=True)
  name = Column(String, index=True)
  phone = Column(String)
  user_id = Column(Integer, ForeignKey("users.id"))
  group_id = Column(Integer, ForeignKey("groups.id"), nullable=True)