from app.routers.database import SessionLocal, engine
from app.routers.models import User
from app.routers.schemas import UserCreate, UserLogin, UserResponse
from fastapi import Depends, FastAPI, HTTPException, Request, status
from passlib.context import CryptContext
from sqlalchemy.orm import Session
from starlette.middleware.sessions import SessionMiddleware

app = FastAPI()

# Подключаем SessionMiddleware для работы с сессиями
app.add_middleware(SessionMiddleware, secret_key="your-super-secret-key-here")

# Настройка хеширования паролей через passlib (bcrypt)
pwd_context = CryptContext(schemes=["sha256_crypt"], deprecated="auto")


def get_password_hash(password: str):
  return pwd_context.hash(password[:72])


def verify_password(plain_password, hashed_password):
  return pwd_context.verify(plain_password[:72], hashed_password)

# Зависимость для получения сессии базы данных
def get_db():
  db = SessionLocal()
  try:
    yield db
  finally:
    db.close()


@app.get("/")
def read_root():
  return {"message": "Contacts API is running"}


# 1. Эндпоинт регистрации
@app.post("/register", response_model=UserResponse)
def register(user: UserCreate, db: Session = Depends(get_db)):
  db_user = db.query(User).filter(User.email == user.email).first()
  if db_user:
    raise HTTPException(status_code=400, detail="Email already registered")

  hashed_password = get_password_hash(user.password)
  new_user = User(
      name=user.name, email=user.email, hashed_password=hashed_password
  )

  db.add(new_user)
  db.commit()
  db.refresh(new_user)
  return new_user


# 2. Эндпоинт входа (логин через сессии)
@app.post("/login")
def login(
    user_data: UserLogin, request: Request, db: Session = Depends(get_db)
):
  user = db.query(User).filter(User.email == user_data.email).first()
  if not user or not verify_password(user_data.password, user.hashed_password):
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Incorrect email or password",
    )

  request.session["user_id"] = user.id
  return {"message": "Logged in successfully", "user_email": user.email}


# 3. Эндпоинт /me для проверки текущего пользователя
@app.get("/me", response_model=UserResponse)
def read_users_me(request: Request, db: Session = Depends(get_db)):
  user_id = request.session.get("user_id")
  if not user_id:
    raise HTTPException(status_code=401, detail="Not authenticated")

  user = db.query(User).filter(User.id == user_id).first()
  if not user:
    raise HTTPException(status_code=404, detail="User not found")
  return user


# 4. Эндпоинт /logout для выхода
@app.post("/logout")
def logout(request: Request):
  request.session.clear()
  return {"message": "Logged out successfully"}